How to play:
Click on CoilCat.exe to begin the game.